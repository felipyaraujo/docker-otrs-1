/**
 * @license Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.plugins.setLang( 'devtools', 'ug', {
	title: 'ئېلېمېنت ئۇچۇرى',
	dialogName: 'سۆزلەشكۈ كۆزنەك ئاتى',
	tabName: 'Tab ئاتى',
	elementId: 'ئېلېمېنت كىملىكى',
	elementType: 'ئېلېمېنت تىپى'
} );

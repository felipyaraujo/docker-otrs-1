/*
 Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang( 'autoembed', 'de', {
	embeddingInProgress: 'Einbetten der eingefügten URL wird versucht...',
	embeddingFailed: 'Diese URL konnte nicht automatisch eingebettet werden.'
} );
